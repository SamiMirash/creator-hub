@echo off
setlocal
title Returnal Multi-Frame Generation - setup

REM ============================================================================
REM  This makes the one file that CANNOT be shipped with the download.
REM
REM  winmm_real.dll is a copy of YOUR OWN Windows system winmm.dll. The proxy
REM  forwards all 180 of its exports there, so the game keeps working normally.
REM  It is not included in this package on purpose: it is Microsoft's binary,
REM  not ours, and redistributing it is not our call to make. Copying it from
REM  your own machine is both correct and free.
REM
REM  The forward target must NOT be called "winmm". A PE forwarder resolves by
REM  base name, and our own module already owns that name, so a file named
REM  winmm would forward into itself.
REM ============================================================================

echo.
echo   Returnal Multi-Frame Generation
echo   -------------------------------
echo.

if not exist "%~dp0winmm.dll" (
  echo   ERROR: winmm.dll is missing from this folder.
  echo   Extract the whole zip and run setup.cmd from inside it.
  echo.
  pause
  exit /b 1
)

if not exist "%WINDIR%\System32\winmm.dll" (
  echo   ERROR: could not find %WINDIR%\System32\winmm.dll
  echo.
  pause
  exit /b 1
)

copy /y "%WINDIR%\System32\winmm.dll" "%~dp0winmm_real.dll" >nul
if errorlevel 1 (
  echo   ERROR: could not create winmm_real.dll
  echo.
  pause
  exit /b 1
)

echo   Created winmm_real.dll from your own Windows copy.
echo.
echo   Now copy BOTH of these into your Returnal folder:
echo.
echo       winmm.dll
echo       winmm_real.dll
echo.
echo   into:
echo.
echo       ...\steamapps\common\Returnal\Returnal\Binaries\Win64\
echo.
echo   You still need NVIDIA Streamline 2.13 in the game's plugin folder.
echo   Full instructions are in README.txt.
echo.
pause
