RETURNAL MULTI-FRAME GENERATION
3X, 4X, 5X and 6X in a game that ships 2X as its ceiling.

  samimirash.com          the article, and everything else
  github.com/SamiMirash   the source, MIT licensed


WHAT THIS IS

Returnal was built against NVIDIA Streamline 1.3.3. Multi-frame generation needs
2.11 or newer, and the game hardcodes a request for exactly one generated frame.
This is a small proxy that sits beside the game and translates the old SDK calls
into the new ones while it runs, so the ceiling goes away.

It is pure NVIDIA: DLSS Frame Generation, Reflex and PCL through Streamline.
There is no FSR, no XeSS and no AMD code anywhere in it.

Nothing on disk is patched. Everything happens in memory. Deleting two files
undoes all of it.


MEASURED, ON ONE MACHINE, IN ONE SCENE

  setting   frames presented   on screen   1% low
  2X               2              130       111
  3X               3              187       109
  4X               4              225       189     <- best consistency
  5X               5              225       148
  6X               6              225       170

Above 4X buys nothing here because the display ceiling is already saturated, and
it costs smoothness. Your numbers will differ.


WHAT YOU NEED

  - Returnal on PC
  - An NVIDIA GPU whose driver supports DLSS Multi-Frame Generation
  - NVIDIA Streamline 2.13, which you download yourself, see step 1
  - Windows 10 or 11, 64-bit


INSTALL

1. GET STREAMLINE 2.13 FROM NVIDIA

   https://github.com/NVIDIA-RTX/Streamline/releases

   Copy these six files into:
     ...\Returnal\Engine\Plugins\Streamline\Binaries\ThirdParty\Win64\

     sl.interposer.dll   sl.common.dll   sl.dlss_g.dll
     sl.reflex.dll       sl.pcl.dll      nvngx_dlssg.dll

   BACK THAT FOLDER UP FIRST. The game ships its own 1.3.3 copies there and you
   are replacing them.

   Use NVIDIA's signed binaries, unmodified. Returnal verifies the Authenticode
   signature on sl.interposer.dll and silently refuses anything that is not
   NVIDIA's own build. That is also why this package does not host a copy.

2. RUN setup.cmd

   It makes winmm_real.dll from your own Windows system file. That file is not
   included here on purpose: it is Microsoft's binary, not ours.

3. COPY winmm.dll AND winmm_real.dll INTO

     ...\steamapps\common\Returnal\Returnal\Binaries\Win64\

4. PICK YOUR MULTIPLIER

   Create or edit returnal_mfg.ini in that same folder:

     [DLSSG]
     InterpolationCount=3     ; 1 = 2X, 2 = 3X, 3 = 4X, 4 = 5X, 5 = 6X

5. LAUNCH THE GAME NORMALLY

   Frame generation switches itself on. There is nothing to enable in the menu,
   and the menu's Frame Generation row stays hidden. That is expected.


UNINSTALL

Delete winmm.dll and winmm_real.dll, and restore the Streamline folder from your
backup.


DOES IT ACTUALLY WORK?

The frame counter can mislead you. If your output is already at a VSync or
refresh ceiling, 2X and 4X show the SAME number because both saturate it. The
honest measure is the base render rate, which you can read from the log the
proxy writes beside the game, returnal_mfg_hook.log:

  DLSSG runtime: r=0 status=0 presented=4 max=5 dynMFG=1

presented=4 is the runtime counting its own output. It tracks the setting: set
2X and it reads 2.

FRAME GENERATION TURNS ITSELF OFF WHEN THE GAME WINDOW IS NOT FOCUSED. That is
NVIDIA's behaviour, not a bug here. If you alt-tab out to read a number, the
number is wrong.


SCOPE

This works on Returnal and nothing else, deliberately. It hardcodes byte offsets
into Returnal's own binaries, the specific names its build exports, and the
particular way this game routes its latency markers. Another title does all
three differently, and a Returnal patch could move them.

If you want something general purpose, look at OptiScaler or DLSS Enabler. This
is not competing with them.


LICENCE

MIT. Source, including why each of three bugs looked like something else, at
github.com/SamiMirash/returnal-mfg

MinHook is BSD-2-Clause and is compiled in. NVIDIA Streamline is under NVIDIA's
own terms and is not redistributed here.

Unofficial and unaffiliated with NVIDIA, Housemarque or Sony. Use at your own
risk.
